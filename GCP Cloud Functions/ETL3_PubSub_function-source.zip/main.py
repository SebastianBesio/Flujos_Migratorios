import functions_framework

import pandas as pd
import requests
from io import BytesIO

from google.cloud import storage

@functions_framework.http
def guardado_undp(request):    

    # Specify the GCS bucket and file name
    bucket_name = 'bucket-pf-flujos_migratorios'
    file_name = 'ArchivosFuente/migracion_undp.csv'
    
    # Initialize a GCS client
    storage_client = storage.Client()
    
    # Specify the bucket and file path in GCS
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)

    csv_object = cargar_undp().to_csv(index=False)

    # Upload the CSV data to GCS
    blob.upload_from_string(csv_object)

    # return listaSalida
    return 'Corrio_Test_migracion_undp'

def cargar_undp():
    url = 'https://hdr.undp.org/sites/default/files/2021-22_HDR/HDR21-22_Composite_indices_complete_time_series.csv'
    response = requests.get(url)
    csv_data = BytesIO(response.content)
    masivo = pd.read_csv(csv_data, encoding='utf-8')
    
    masivo.rename(columns={'country':'Country Name'}, inplace=True)
    prefijos = ['hdi_1', 'hdi_2', 'le_1', 'le_2','mys_1','mys_2', 'gnipc_1', 'gnipc_2']
    columnas_seleccionadas = ['Country Name', 'hdicode'] + [col for col in masivo.columns if any(col.startswith(prefix) for prefix in prefijos)]
    masivo_final = masivo[columnas_seleccionadas]
    
    correcciones_paises = {
        'Venezuela (Bolivarian Republic of)': 'Venezuela',
        'Antigua and Barbuda': 'Antigua y Barbuda',
        'Belize': 'Belice',
        'Brazil': 'Brasil',
        'Bolivia (Plurinational State of)': 'Bolivia',
        'Grenada': 'Granada',
        'United States': 'Estados Unidos',
        'Mexico': 'Mexico',
        'Dominican Republic': 'Santa Lucia',
        'Saint Lucia': 'Republica Dominicana',
        'Trinidad and Tobago': 'Trinidad y Tobago',
        'Costa Rica' : 'Costa Rica',
        'El Salvador':'El Salvador',
        'Estados Unidos':'Estados Unidos'
    }
    masivo_final['Country Name'] = masivo_final['Country Name'].replace(correcciones_paises)

    df = pd.DataFrame()
    paises = ['Antigua y Barbuda','Argentina','Bahamas','Belice','Bolivia','Brasil','Canada','Chile','Colombia','Costa Rica','Cuba','Ecuador','El Salvador','Estados Unidos','Granada','Guatemala','Guyana','Haiti','Honduras','Jamaica','Mexico','Nicaragua','Panama','Paraguay','Peru','Republica Dominicana','Santa Lucia','Trinidad y Tobago','Uruguay','Venezuela']
    paises_df = pd.DataFrame({'Country Name': paises})

    columnas_hdi = [col for col in masivo_final.columns if col.startswith('hdi_1') or col.startswith('hdi_2')]
    columnas_esperanza_vida = [col for col in masivo_final.columns if col.startswith('le_1') or col.startswith('le_2')]
    columnas_año_prom_esc = [col for col in masivo_final.columns if col.startswith('mys_1') or col.startswith('mys_2')]
    columnas_PBI_per_cap_aj = [col for col in masivo_final.columns if col.startswith('gnipc_1') or col.startswith('gnipc_2')]

    masivo_final2 = pd.melt(masivo_final, id_vars=['Country Name'], value_vars=columnas_hdi, var_name='Año', value_name='hdi')
    masivo_final2 = masivo_final2.merge(paises_df, on='Country Name')
    df['Pais'] = masivo_final2['Country Name']
    df['hdi'] = masivo_final2['hdi']

    masivo_final2 = pd.melt(masivo_final, id_vars=['Country Name'], value_vars=columnas_esperanza_vida, var_name='Año', value_name='Esperanza_vida')
    masivo_final2 = masivo_final2.merge(paises_df, on='Country Name')
    df['Esperanza_vida'] = masivo_final2['Esperanza_vida']

    masivo_final2 = pd.melt(masivo_final, id_vars=['Country Name'], value_vars=columnas_año_prom_esc, var_name='Año', value_name='Año_prom_esc')
    masivo_final2 = masivo_final2.merge(paises_df, on='Country Name')
    df['Anio_prom_esc'] = masivo_final2['Año_prom_esc']

    masivo_final2 = pd.melt(masivo_final, id_vars=['Country Name'], value_vars=columnas_PBI_per_cap_aj, var_name='Año', value_name='PBI_per_cap_aj')
    masivo_final2 = masivo_final2.merge(paises_df, on='Country Name')
    df['PBI_per_cap_aj'] = masivo_final2['PBI_per_cap_aj']

    anios = masivo_final2['Año'].str.extract(r'(\d{4})')[0]
    df['Anio'] = anios
    
    df['Pais'] = df['Pais'].astype(str)
    df['Anio'] = df['Anio'].astype(int)

    return df