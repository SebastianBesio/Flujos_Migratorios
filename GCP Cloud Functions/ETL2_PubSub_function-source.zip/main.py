import functions_framework
import pandas as pd
import os 
from google.cloud import storage 
import requests
import pandas as pd

#@functions_framework.http
# Elegir los países para consultar datos con sus ID
country_call = 'ATG;ARG;BHS;BLZ;BOL;BRA;CAN;CHL;COL;CRI;CUB;DOM;ECU;SLV;GRD;GTM;GUY;HTI;HND;JAM;MEX;NIC;PAN;PRY;PER;LCA;TTO;USA;URY;VEN'

def consulta(num_pages, country_call, code):
    url = f'http://api.worldbank.org/v2/country/{country_call}/indicator/{code}?date=1990:2022&per_page={num_pages}'
    response = requests.get(url, {'format':'json'})
    data = response.json()[1]

    for item in data:
        item['indicator'] = item['indicator']['value']
        item['country'] = item['country']['value']

    df = pd.DataFrame(data)

    # Eliminar columnas
    columns_drop = ['indicator', 'countryiso3code', 'unit', 'obs_status', 'decimal']
    df = df.drop(columns_drop, axis=1)

    # Invertir año
    df = df.sort_values(by=['country', 'date'], ascending=[True, True])

    # Renombrar paises a ESP
    df['country'].replace(['Antigua and Barbuda', 'Bahamas, The', 'Belize',
        'Brazil', 'Dominican Republic', 'Grenada',
        'St. Lucia', 'Trinidad and Tobago',
        'United States', 'Venezuela, RB'], 
        ['Antigua y Barbuda', 'Bahamas', 'Belice',
        'Brasil', 'Republica Dominicana', 'Granada',
        'Santa Lucia', 'Trinidad y Tobago',
        'Estados Unidos', 'Venezuela'], inplace = True)

    return df

def unir():
    df1 = consulta(1100, country_call, 'SM.POP.NETM')
    df2 = consulta(1100, country_call, 'SL.UEM.TOTL.ZS')
    df3 = consulta(1100, country_call, 'NY.GDP.PCAP.CD')

    df_combinado = pd.merge(df1, df2, on=['country', 'date'])
    df_combinado = pd.merge(df_combinado, df3, on=['country', 'date'])

    df_combinado.columns = ['country', 'date', 'migracion_neta', 'desempleo', 'pbi_per_capita']

    # Renombrar columnas
    df_combinado.rename(columns={'country': 'Pais', 'date': 'Anio'}, inplace=True)

    return df_combinado

@functions_framework.http
def guardado_API_BM(request):    

    # Specify the GCS bucket and file name
    bucket_name = 'bucket-pf-flujos_migratorios'
    file_name = 'ArchivosFuente/migracion_desempleo_pbi_per_capita.csv'
    
    # Initialize a GCS client
    storage_client = storage.Client()
    
    # Specify the bucket and file path in GCS
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)

    csv_object = unir().to_csv(index=False)

    # Upload the CSV data to GCS
    blob.upload_from_string(csv_object)

    return 'Corrio_Test_save_API_BM'