import base64
import functions_framework
from google.cloud import bigquery, storage
import pandas as pd
from prophet import Prophet

def lectura_csv_bucket(file_path, bucket_name):
    """ 
    Lectura de un csv en file_path desde el Bucket bucket_name.
    Retorna un DataFrame con el csv leido.
    """
    # Crea un cliente de almacenamiento de Google Cloud
    storage_client = storage.Client()

    # Obtiene el cubo de almacenamiento
    bucket = storage_client.get_bucket(bucket_name)

    # Obtiene el objeto de archivo CSV
    blob = bucket.blob(file_path)

    # Lee el contenido del archivo CSV en un DataFrame de Pandas
    with blob.open("r") as file:
        df = pd.read_csv(file)
    
    return df

def carga_tabla_bq(df, dataset_id, table_id, bucket, project_id, primary_key):
    client = bigquery.Client()

    # Define el ID completo de la tabla en BigQuery
    table_ref = client.dataset(dataset_id).table(table_id)

    # Query existing data from the table
    query = f"SELECT {primary_key} FROM `{project_id}.{dataset_id}.{table_id}`"
    existing_primary_keys = set(row[primary_key] for row in client.query(query))

    # Identify unique rows based on primary key
    new_rows = df[~df[primary_key].isin(existing_primary_keys)]
    
    print(new_rows)
    
    # Load the new rows into BigQuery
    if not new_rows.empty:
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_APPEND", # Append al final de la tabla
            autodetect=True, # Detectar automáticamente el esquema de la tabla
        )

        job = client.load_table_from_dataframe(new_rows, table_ref, job_config=job_config)
        job.result()

def guardado_csv_bucket(df, file_path, bucket_name):
    """ 
    Guardado de un DataFrame en csv en file_path desde el Bucket bucket_name.
    """
    # Guarda el DataFrame en un archivo CSV
    csv_data = df.to_csv(index=False)

    # Crea un cliente de almacenamiento de Google Cloud
    storage_client = storage.Client()

    # Obtiene el cubo de almacenamiento
    bucket = storage_client.get_bucket(bucket_name)

    # Carga el archivo CSV en el bucket de Google Cloud Storage
    blob = bucket.blob(file_path)
    blob.upload_from_string(csv_data)

# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def guardado_bq(cloud_event):

    # Definir nombre del Dataset
    dataset_id = "Migraciones"
    project_id = "ethereal-accord-397414"
     
    ############################################################################
    # Generacion Data Frames preparados para BigQuery  y guardado CSV respaldo en el Cloud Storage
    ############################################################################
    source_folder_name = "ArchivosFuente/"
    bq_folder_name = "ParaBigQuery/"
    bucket_name = 'bucket-pf-flujos_migratorios'
    
    # Lectura de todos los csv fuentes desde el Bucket.
    file_path_undp = source_folder_name + 'migracion_undp.csv'
    df_undp = lectura_csv_bucket(file_path_undp, bucket_name)
    file_path_bm = source_folder_name + 'migracion_desempleo_pbi_per_capita.csv'
    df_bm = lectura_csv_bucket(file_path_bm, bucket_name)
    file_path_inmigracion = source_folder_name + 'Inmigracion_por_pais.csv'
    df_inmigracion = lectura_csv_bucket(file_path_inmigracion, bucket_name)

    ######################################
    # Generacion DF y CSV para tabla 'pais'
    ######################################

    # Generador de 'id_pais'
    pais = []
    j = 1
    for i in (df_undp['Pais'].unique()):
        pais.append([j,i])
        j += 1

    df_bq_pais = pd.DataFrame(pais, columns = ['id_pais','nombre'])

    # Guardo CSV
    file_path = bq_folder_name + 'pais.csv'
    guardado_csv_bucket(df_bq_pais, file_path, bucket_name)

    ######################################
    # Generacion DF y CSV para tabla 'fac_social'
    ######################################

    # Como son todos del mismo Dataset no necesitamos hacer un merge.
    df_bq_fac_soc = df_undp.copy()
    df_bq_fac_soc['id_pais'] = df_undp['Pais'].replace(dict(zip(df_bq_pais["nombre"], df_bq_pais["id_pais"])))
    df_bq_fac_soc['id_fac_soc'] = 10000 * df_bq_fac_soc['Anio'] + df_bq_fac_soc['id_pais']

    df_bq_fac_soc.drop(columns=['Pais', 'id_pais', 'Anio', 'PBI_per_cap_aj'], inplace=True)

    df_bq_fac_soc.head()

    # Guardo CSV
    file_path = bq_folder_name + 'fac_social.csv'
    guardado_csv_bucket(df_bq_fac_soc, file_path, bucket_name)

    ######################################
    # Generacion DF y CSV para tabla 'fac_economico'
    ######################################

    df_bq_fac_eco = df_undp.merge(df_bm, on=['Pais', 'Anio'])

    df_bq_fac_eco['id_pais'] = df_bq_fac_eco['Pais'].replace(dict(zip(df_bq_pais["nombre"], df_bq_pais["id_pais"])))
    df_bq_fac_eco['id_fac_eco'] = 10000 * df_bq_fac_eco['Anio'] + df_bq_fac_eco['id_pais']

    df_bq_fac_eco.drop(columns=['Pais', 'id_pais', 'Anio', 'hdi', 'Esperanza_vida', 'Anio_prom_esc', 'migracion_neta'], inplace=True)

    df_bq_fac_eco.rename(columns={'PBI_per_cap_aj': 'pbi_per_cap_aj'}, inplace=True)

    # Guardo CSV
    file_path = bq_folder_name + 'fac_economico.csv'
    guardado_csv_bucket(df_bq_fac_eco, file_path, bucket_name)

    ######################################
    # Generacion DF y CSV para tabla 'inmigracion'
    ######################################

    df_bq_inmigracion = df_inmigracion.copy()
    df_bq_inmigracion['id_pais'] = df_bq_inmigracion['Pais'].replace(dict(zip(df_bq_pais["nombre"], df_bq_pais["id_pais"])))
    df_bq_inmigracion['id_inmigracion'] = 10000 * df_bq_inmigracion['Anio'] + df_bq_inmigracion['id_pais']

    df_bq_inmigracion.drop(columns=['Pais', 'id_pais', 'Anio'], inplace=True)
    # Renombro asi coinciden
    df_bq_inmigracion.rename(columns={'Inmigrantes_hombres': 'hombres', 'Inmigrantes_mujeres': 'mujeres', 'Inmigrantes': 'total'}, inplace=True)

    # Paso a Int
    df_bq_inmigracion[df_bq_inmigracion.columns] = df_bq_inmigracion[df_bq_inmigracion.columns].astype('Int64')

    # Guardo CSV
    file_path = bq_folder_name + 'inmigracion.csv'
    guardado_csv_bucket(df_bq_inmigracion, file_path, bucket_name)

    ######################################
    # Generacion DF y CSV para tabla 'migracion'
    ######################################

    df_bq_migracion = df_bm.copy()
    df_bq_migracion['id_pais'] = df_bq_migracion['Pais'].replace(dict(zip(df_bq_pais["nombre"], df_bq_pais["id_pais"])))
    df_bq_migracion['id_migracion'] = 10000 * df_bq_migracion['Anio'] + df_bq_migracion['id_pais']

    df_bq_migracion.drop(columns=['Pais', 'desempleo', 'pbi_per_capita'], inplace=True)
    # Anio con minuscula
    df_bq_migracion.rename(columns={'Anio': 'anio'}, inplace=True)

    # crear ids de los otros copiando de id_migracion
    df_bq_migracion['id_inmigracion'] = df_bq_migracion['id_migracion']
    df_bq_migracion['id_fac_soc'] = df_bq_migracion['id_migracion']
    df_bq_migracion['id_fac_eco'] = df_bq_migracion['id_migracion']

    #Quitar id erroneos
    df_bq_migracion.loc[~df_bq_migracion['id_migracion'].isin(df_bq_inmigracion['id_inmigracion']), 'id_inmigracion'] = None
    df_bq_migracion.loc[~df_bq_migracion['id_migracion'].isin(df_bq_fac_soc['id_fac_soc']), 'id_fac_soc'] = None
    df_bq_migracion.loc[~df_bq_migracion['id_migracion'].isin(df_bq_fac_eco['id_fac_eco']), 'id_fac_eco'] = None

    # Vuelvo a convertir a Int
    df_bq_migracion['id_inmigracion'] = df_bq_migracion['id_inmigracion'].astype('Int64')
    df_bq_migracion['id_fac_soc'] = df_bq_migracion['id_fac_soc'].astype('Int64')
    df_bq_migracion['id_fac_eco'] = df_bq_migracion['id_fac_eco'].astype('Int64')
    df_bq_migracion['migracion_neta'] = df_bq_migracion['migracion_neta'].astype('Int64')

    # Convertir anio a tipo DATE
    df_bq_migracion['anio'] = df_bq_migracion['anio'].astype("string") + "-12-31"
    df_bq_migracion['anio'] =  pd.to_datetime(df_bq_migracion['anio'], format="%Y-%m-%d")

    # Modelo que predice los proximas migraciones netas por pais.
    df_bq_migracion = modelo_pred_migracion_neta(df_bq_migracion)

    # Guardo CSV
    file_path = bq_folder_name + 'migracion.csv'
    guardado_csv_bucket(df_bq_migracion, file_path, bucket_name)

    ######################################
    # Pasaje a BigQuery
    ######################################
    
    carga_tabla_bq(df_bq_pais, dataset_id, 'pais', bucket_name, project_id, 'id_pais')
    carga_tabla_bq(df_bq_fac_soc, dataset_id, 'fac_social', bucket_name, project_id, 'id_fac_soc')
    carga_tabla_bq(df_bq_fac_eco, dataset_id, 'fac_economico', bucket_name, project_id, 'id_fac_eco')
    carga_tabla_bq(df_bq_inmigracion, dataset_id, 'inmigracion', bucket_name, project_id, 'id_inmigracion')
    carga_tabla_bq(df_bq_migracion, dataset_id, 'migracion', bucket_name, project_id, 'id_migracion')

    return 'Ejecuto_ETL_Hacia_BigQuery'

def modelo_pred_migracion_neta(df_tot):
    """
     Modelo que predice los proximas migraciones netas por pais.
    """
    # Obtengo Id Paises
    paises = df_tot['id_pais'].unique()

    def predecir(data, columna, periodo, scale, idpais):
        
        # Filtro por pais.
        df_pais = data[data['id_pais'] == idpais]

        # Renombrar las columnas para que sean compatibles con Prophet.
        df_prophet = pd.DataFrame()
        df_prophet['ds'] = df_pais['anio']
        df_prophet['y'] = df_pais[columna]

        # Crear un modelo Prophet
        model = Prophet(changepoint_prior_scale=scale)

        # Ajustar el modelo a los datos
        model.fit(df_prophet)

        # Crear un DataFrame con las fechas futuras que deseas predecir
        future = model.make_future_dataframe(periods=periodo, freq='Y')

        # Realizar las predicciones
        forecast = model.predict(future)

        return forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']]

    df_pred = pd.DataFrame(columns=['ds', 'yhat', 'id_pais'])

    # Hago la prediccion para cada uno de los paises.
    for p in paises:
        df_forcast = predecir(df_tot, 'migracion_neta', 5, 2, p)
        df_forcast = df_forcast[['ds', 'yhat']]
        df_forcast['id_pais'] = p
        df_pred = df_pred.merge(df_forcast, how='outer')

    # Renombro columnas
    df_pred.rename(columns={'ds': 'anio', 'yhat': 'migracion_neta_pred'}, inplace=True)

    # Pasar prediccion a valores enteros
    df_pred['migracion_neta_pred'] =  df_pred['migracion_neta_pred'].astype(int)

    # Retornar dataframe pero con la nueva columna creada
    return df_pred.merge(df_tot, how='outer', on=['id_pais', 'anio'])