import functions_framework
import pandas as pd

import urllib.request
from bs4 import BeautifulSoup
import re
import json

from google.cloud import storage

@functions_framework.http
def WebScrapping(request):    

    # Definir años y paises
    years = [1990, 1995, 2000, 2005, 2010, 2015, 2020]

    countries = ['Argentina', 'Antigua-Barbuda', 'Bahamas', 'Belice', 'Bolivia',
        'Brasil', 'Canada', 'Chile', 'Colombia', 'Costa-Rica', 'Cuba',
        'Republica-Dominicana', 'Ecuador', 'Granada', 'Guatemala',
        'Guyana', 'Honduras', 'Haiti', 'Jamaica', 'Santa-Lucia', 'Mexico',
        'Nicaragua', 'Panama', 'Peru', 'Paraguay', 'El-Salvador',
        'Trinidad-Tobago', 'Uruguay', 'usa', 'Venezuela']

    # Lista de diccionarios con cada fila de datos
    listaSalida = []

    # Recorrer todos los países y años
    for y in years:
        for c in countries:
            nuevaFila = extraerDatosInmigracion(y, c)
            print(nuevaFila)
            listaSalida.append(nuevaFila)
    
    # Pasado a Dataframe para expandir todos los datos
    df_inm_por_pais = pd.DataFrame(listaSalida)
    df_inm_por_pais = df_inm_por_pais.join(pd.DataFrame(df_inm_por_pais['Origen'].tolist()))
    df_inm_por_pais.drop(columns='Origen', inplace=True)

    df_inm_por_pais = df_inm_por_pais[['Pais',	'Inmigrantes hombres',	'Inmigrantes mujeres',	'Inmigrantes',	'Anio',
    'Argentina', 'Antigua y Barbuda', 'Bahamas', 'Belice', 'Bolivia',
    'Brasil', 'Canada', 'Chile', 'Colombia', 'Costa Rica', 'Cuba',
    'Santa Lucia', 'Ecuador', 'Granada', 'Guatemala', 'Guyana',
    'Honduras', 'Haiti', 'Jamaica', 'Republica Dominicana', 'Mexico',
    'Nicaragua', 'Panama', 'Peru', 'Paraguay', 'El Salvador',
    'Trinidad y Tobago', 'Uruguay', 'Estados Unidos', 'Venezuela']]

    df_inm_por_pais.rename(columns={'Inmigrantes hombres': 'Inmigrantes_hombres', 'Inmigrantes mujeres': 'Inmigrantes_mujeres',
        'Antigua y Barbuda': 'Antigua_y_Barbuda', 'Costa Rica': 'Costa_Rica', 'Santa Lucia': 'Santa_Lucia',
        'Republica Dominicana': 'Republica_Dominicana', 'El Salvador': 'El_Salvador',
        'Trinidad y Tobago': 'Trinidad_y_Tobago', 'Estados Unidos': 'Estados_Unidos'}, inplace=True)
    
    # Pasado a CSV
    csv_object = df_inm_por_pais.to_csv(index=False)

    # Specify the GCS bucket and file name
    bucket_name = 'bucket-pf-flujos_migratorios'
    file_name = 'ArchivosFuente/Inmigracion_por_pais.csv'
    
    # Initialize a GCS client
    storage_client = storage.Client()
    
    # Specify the bucket and file path in GCS
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)    

    # Upload the CSV data to GCS
    blob.upload_from_string(csv_object)

    return 'Corrio_Test_save_WS'

def extraerDatosInmigracion(year, country):
    """
    Extraccion de datos de datosmacro.expansion.com de composición de inmigrantes.

    year (int): Año de estudio [1990, 1995, 2000, 2005, 2010, 2015, 2020]
    country (str): Pais de estudio del cual se quiere saber su composición de inmigrantes.

    Ejemplo:
        url = 'https://datosmacro.expansion.com/demografia/migracion/inmigracion/venezuela?anio=1990#geo0'
    """
    # URL Base a consultar.
    url = f'https://datosmacro.expansion.com/demografia/migracion/inmigracion/{country}?anio={year}#geo0'

    # Obtengo el HTML
    htmlPage = urllib.request.urlopen(url)

    # Beautiful Soup: Para parsearlo como HTML. Y lo dejo mas bonito e indentado con prettify.
    pageBS = BeautifulSoup(htmlPage, 'html.parser')
    nicePageBS = pageBS.prettify()

    # Encontrar los dos encabezados de las dos tablas.
    # dataMT[0]=new google.visualization.DataTable({cols: [{type:'string',label:"Venezuela"},{type:'number',label:"Inmigrantes hombres"},{type:'number',label:"Inmigrantes mujeres"},{type:'number',label:"Inmigrantes"},],
    pattern = r'dataMT\[0\]=new google.visualization.DataTable\({cols: (\[.*?,\]),'
    encabezadosRaw = re.findall(pattern, nicePageBS)

    # Encontrar los valores de las dos tablas
    # rows: [{c:[{v:'Venezuela'},{v:517579},{v:507430},{v:1025009},]},]});
    pattern = r'rows: \[({c:\[.*?,\])},]}\);'
    valoresRaw = re.findall(pattern, nicePageBS)

    # Validacion de que no tenga la tabla una tercera tabla que no nos sirve, esa siempre queda en el medio.
    if 'Fecha' in encabezadosRaw[1]:
        del(encabezadosRaw[1])
    if 'new Date' in valoresRaw[1]:
        del(valoresRaw[1])
    
    # Limpiar datos
    for i in range(len(encabezadosRaw)):
        encabezadosRaw[i] = LimpiarDatos(encabezadosRaw[i])
    for i in range(len(valoresRaw)):
        valoresRaw[i] = LimpiarDatos(valoresRaw[i])
        
    #######################################
    # Extrarer los datos a formatos limpios
    #######################################

    # **Encabezados**
    # ['[{type:\'string\',label:"Colombia"},{type:\'number\',label:"Inmigrantes hombres"},{type:\'number\',label:"Inmigrantes mujeres"},{type:\'number\',label:"Inmigrantes"},]','[{type:\'string\',label:"Países"},{type:\'number\',label:"Inmigrantes"},{type:\'string\',label:"Países"},]']
    patternEncab = r'label:"(.*?)"'
    encabezadosTabla1 = re.findall(patternEncab, encabezadosRaw[0])
    
    # Correccion del nombre del primer campo
    encabezadosTabla1[0] = 'Pais'

    # **Datos**
    # ["{c:[{v:'Colombia'},{v:56223},{v:53386},{v:109609},]", "{c:[{v:'VE'},{v:37200},{v:'Venezuela'},]},{c:[{v:'US'},{v:15068},{v:'Estados Unidos'},]},{c:[{v:'EC'},{v:11964},{v:'Ecuador'},]},
    patternDatos = r'{v:(.*?)},'
    valoresTabla1 = re.findall(patternDatos, valoresRaw[0])

    # Considerar que no quiero quedarme con el codigo de pais, {c:[{v:'VE'},{v:37200},{v:'Venezuela'},]},
    patternDatos = r',({.*?])},'
    filasTabla2 = re.findall(patternDatos, valoresRaw[1])
    #
    patternDatos = r'{v:(.*?)},'
    valoresTabla2 = [re.findall(patternDatos, fila) for fila in filasTabla2]
    
    # Limpiar todas las comillas ' indeseadas
    for i in range(len(valoresTabla1)):
            valoresTabla1[i] = valoresTabla1[i] .replace("'", "")

    for i in range(len(valoresTabla2)):
        for j in range(len(valoresTabla2[i])):
            valoresTabla2[i][j] = valoresTabla2[i][j] .replace("'", "")
    
    # Invertir, dar vuelta el orden para que quede el pais primero [('Venezuela', '37200'), ('Estados Unidos', '15068'), ...
    valoresTabla2_reord_dict = dict([(e[1], e[0]) for e in valoresTabla2])

    # Llevado a DataFrame para preparar algunos datos.
    df1 = pd.DataFrame([valoresTabla1], columns = encabezadosTabla1)

    # Preparo datos para JSON, los convierto a dict.
    dict1 = df1.to_dict('records')

    # Les saco el formato de lista de un elemento 1.
    dict1 = dict1[0]
    # Le agrego el año.
    dict1["Anio"] = year

    # Junto los datos en un unico diccionario.
    dictSalida = dict1
    dictSalida["Origen"] = valoresTabla2_reord_dict
    
    return dictSalida


def LimpiarDatos(sucio):
    return sucio.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("ü", "u").replace("Á", "A").replace("ñ", "n")